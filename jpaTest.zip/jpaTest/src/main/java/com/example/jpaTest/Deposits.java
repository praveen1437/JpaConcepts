package com.example.jpaTest;

import jakarta.persistence.*;

@Entity
@Table(name = "deposits")
public class Deposits {

    @Id
    private Long id;
    @OneToOne
    @JoinColumn(name = "detail_id")
    private PaymentDetails paymentDetails;
}
