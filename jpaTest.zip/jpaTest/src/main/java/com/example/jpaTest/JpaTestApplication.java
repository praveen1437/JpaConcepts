package com.example.jpaTest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.Date;

@SpringBootApplication
public class JpaTestApplication {
	@Autowired
	PaymentDetailsRepo  paymentDetailsRepo;

	public static void main(String[] args) {
		SpringApplication.run(JpaTestApplication.class, args);

	}
	@Bean("random")
	public Date Test() {
		System.out.println("in bean : " + paymentDetailsRepo.findBydetailId(1l));
		return new Date();
	}

}
