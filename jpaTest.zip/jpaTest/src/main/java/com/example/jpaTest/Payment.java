package com.example.jpaTest;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Entity
@Table(name = "payment")
@Data
public class Payment {

    @Id
    private Long id;
    @OneToMany
    @JoinColumn(name = "detail_id")
    private List<PaymentDetails> list;

}
