package com.example.jpaTest;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "payment_attributes")
@Data
public class PaymentAttributes {

    @Id
    @Column
    private Long id;
    @Column(name = "attr")
    private String attr;
}
