package com.example.jpaTest;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Entity
@Table(name = "payment_details")
@Data
public class PaymentDetails {

    @Id
    private Long id;
    @Column(name = "amount")
    private double amount;

    @OneToMany
    @JoinColumn(name = "attr_id")
    private List<PaymentAttributes> attrilist;
 }
