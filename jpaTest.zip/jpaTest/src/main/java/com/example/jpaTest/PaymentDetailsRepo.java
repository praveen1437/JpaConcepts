package com.example.jpaTest;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface PaymentDetailsRepo extends JpaRepository<Deposits,Long> {
    @Query(value = "select new com.example.jpaTest.PaymentResponse(pd.amount,p.id) from Payment p,Deposits d inner join d.paymentDetails pd inner join pd.attrilist pda where pda.id =:id and p.id=:id")
    List<PaymentResponse> findBydetailId(long id);
}
