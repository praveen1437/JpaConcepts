package com.example.jpaTest.services;

import com.example.jpaTest.*;
import jakarta.persistence.EntityManager;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.Root;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class DepositService {

    @Autowired
    DepositRepo depositRepo;
    @Autowired
    EntityManager entityManager;

    public List<PaymentResponse> getPaymentResponse() {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<PaymentResponse> criteriaQuery = criteriaBuilder.createQuery(PaymentResponse.class);
        Root<Deposits> depositsRoot = criteriaQuery.from(Deposits.class);
        Join<Deposits, PaymentDetails> paymentDetailsJoin = depositsRoot.join("paymentDetails");
        Join<Payment, PaymentDetails> paymentJoin = paymentDetailsJoin.join("id");

        criteriaQuery.select(criteriaBuilder.construct(
             PaymentResponse.class, paymentDetailsJoin.get("amount"),paymentJoin.get("id")
        ));
        return entityManager.createQuery(criteriaQuery).getResultList();
    }



}
